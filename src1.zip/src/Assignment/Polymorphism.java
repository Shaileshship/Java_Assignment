//package Assignment;
//
//class Shapes {
//    float l = 3.4f;
//
//    void print() {
//        System.out.println("The Length of the shape is = " + l);
//    }
//}
//
//class Rectangles extends Shapes {
//    float l = 4.2f;
//    float b = 8.6f;
//    float area = l * b;
//
//    void print() {
//        System.out.println("The Area of the Rectangle is = " + area);
//    }
//}
//
//class Triangles extends Shapes {
//    float base = 5.4f;
//    float height = 4.3f;
//    float area = 0.5f * base * height;
//
//    void print() {
//        System.out.println("The Area of the Triangle is = " + area);
//    }
//}
//
//class Squares extends Shapes {
//    float side = 3.9f;
//    float area = side * side;
//
//    void print() {
//        System.out.println("The Area of the Square is = " + area);
//    }
//}
//
//class Rhombuss extends Shapes {
//    float d1 = 3.9f;
//    float d2 = 7.6f;
//    float area = 0.5f * d1 * d2;
//
//    void print() {
//        System.out.println("The Area of the Rhombus is = " + area);
//    }
//}
//
//public class Polymorphism {
//    public static void main(String[] args) {
//        Shapes b;
//
//        b = new Rectangles();
//        b.print();
//
//        b = new Triangles();
//        b.print();
//
//        b = new Squares();
//        b.print();
//
//        b = new Rhombuss();
//        b.print();
//    }
//}


