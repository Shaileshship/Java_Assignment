package Assignment;

public class oops {
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(
			String password) {
		this.password = password;
	}
	public long getAadhar() {
		return aadhar;
	}
	public void setAadhar(long aadhar) {
		this.aadhar = aadhar;
	}
	private int custid;
	private String password;
	private long aadhar;
	
}
